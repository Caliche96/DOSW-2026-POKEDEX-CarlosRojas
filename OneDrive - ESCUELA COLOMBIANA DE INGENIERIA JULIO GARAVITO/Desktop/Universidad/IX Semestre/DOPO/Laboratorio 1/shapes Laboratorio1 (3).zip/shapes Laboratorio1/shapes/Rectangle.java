package shapes;

import java.awt.*;

/**
 * A rectangle that can be manipulated and that draws itself on a canvas.
 * 
 * @author  Michael Kolling and David J. Barnes (Modified)
 * @version 1.0  (15 July 2000)()
 */


 
public class Rectangle{

    public static int EDGES = 4;
    
    private int height;
    private int width;
    private int xPosition;
    private int yPosition;
    private String color;
    private boolean isVisible;

    /**
     * Create a new rectangle at default position with default color.
     * Changes= Create a square with a Perimeter.
     */
    public Rectangle(int perimetro){
        
        int size= perimetro/4;
        width= size;
        height= size;
        xPosition = 70;
        yPosition = 15;
        color = "magenta";
        isVisible = true;
    }
    

    /**
     * Make this rectangle visible. If it was already visible, do nothing.
     */
    public void makeVisible(){
        isVisible = true;
        draw();
    }
    
    /**
     * Make this rectangle invisible. If it was already invisible, do nothing.
     */
    public void makeInvisible(){
        erase();
        isVisible = false;
    }
    
    /**
     * Move the rectangle a few pixels to the right.
     */
    public void moveRight(){
        moveHorizontal(20);
    }

    /**
     * Move the rectangle a few pixels to the left.
     */
    public void moveLeft(){
        moveHorizontal(-20);
    }

    /**
     * Move the rectangle a few pixels up.
     */
    public void moveUp(){
        moveVertical(-20);
    }

    /**
     * Move the rectangle a few pixels down.
     */
    public void moveDown(){
        moveVertical(20);
    }

    /**
     * Move the rectangle horizontally.
     * @param distance the desired distance in pixels
     */
    public void moveHorizontal(int distance){
        erase();
        xPosition += distance;
        draw();
    }

    /**
     * Move the rectangle vertically.
     * @param distance the desired distance in pixels
     */
    public void moveVertical(int distance){
        erase();
        yPosition += distance;
        draw();
    }

    /**
     * Slowly move the rectangle horizontally.
     * @param distance the desired distance in pixels
     */
    public void slowMoveHorizontal(int distance){
        int delta;

        if(distance < 0) {
            delta = -1;
            distance = -distance;
        } else {
            delta = 1;
        }

        for(int i = 0; i < distance; i++){
            xPosition += delta;
            draw();
        }
    }

    /**
     * Slowly move the rectangle vertically.
     * @param distance the desired distance in pixels
     */
    public void slowMoveVertical(int distance){
        int delta;

        if(distance < 0) {
            delta = -1;
            distance = -distance;
        } else {
            delta = 1;
        }

        for(int i = 0; i < distance; i++){
            yPosition += delta;
            draw();
        }
    }

    /**
     * Change the size to the new size
     * @param newHeight the new height in pixels. newHeight must be >=0.
     * @param newWidht the new width in pixels. newWidth must be >=0.
     */
    public void changeSize(int newHeight, int newWidth) {
        erase();
        height = newHeight;
        width = newWidth;
        draw();
    }
    
    /**
     * Change the color. 
     * @param color the new color. Valid colors are "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public void changeColor(String newColor){
        color = newColor;
        draw();
    }

    /*
     * Draw the rectangle with current specifications on screen.
     */

    private void draw() {
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color,
                new java.awt.Rectangle(xPosition, yPosition, 
                                       width, height));
            canvas.wait(10);
        }
    }

    /*
     * Erase the rectangle on screen.
     */
    private void erase(){
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
    
    /**
     * Método sobre el perímetro del rectangulo
     */
    public int perimeter(){
        return 2*(height+width);
    }
    
    /**
     * Método que aumentará o disminuirá el tamaño del rectangulo un 100%
     * '+' Duplica el tamaño del rectángulo
     * '-' Disminuye el tamaño del rectángulo
     */
    public void zoom(char z){
        double factor;
        
         if (z == '+') {
            factor =2.0;

        }else if (z=='-'){
            factor= 0.5;
        }else {
            return;
        }
        
        int newHeight=(int)Math.round(height*factor);
        int newWidth =(int)Math.round(width*factor);
        
        if (newHeight<1) newHeight=1;
        if (newWidth<1) newWidth=1;
        
        changeSize(newHeight,newWidth);
    }
    
    /**
     * Mueve el rectangulo en digaonal cayendo
     * @params
     */
    
    public void walk( int times){
        int steps= Math.abs(times);
        int dx = (times>= 0) ? 20:-20;  //Acá se caerá hacia la izquierda o hacia la derecha
        
        for (int i = 0; i<steps; i++){
            erase();
            xPosition += dx;
            yPosition += 20;        //Acá hará el salto de caída x veces
            draw();
            
        }
    }   
    
    //Nuevo método
    /**
     * Verifica si el rectángulo es un cuadrado
     */
    public boolean esCuadrado(){
        return width== height;
    }
}

